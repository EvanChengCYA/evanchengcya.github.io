import numpy as np
from sklearn.model_selection import train_test_split
import torch
from torch import nn, optim
from torch.utils.data import Dataset, DataLoader
import h5py
import argparse
import os
import re

class Normalizer(object):
    def __init__(self, tensor):
        """tensor is taken as a sample to calculate the mean and std"""
        self.mean = torch.mean(tensor, dim=0)
        self.std = torch.std(tensor, dim=0)
        self.device = torch.device("cpu")  # Default device is CPU
    
    # def to(self, device):
    #     """Move mean and std tensors to the specified device."""
    #     self.mean = self.mean.to(device)
    #     self.std = self.std.to(device)
    #     self.device = device
    
    def norm(self, tensor):
        return (tensor - self.mean.to(tensor.device)) / self.std.to(tensor.device)
    
    def denorm(self, normed_tensor):
        return normed_tensor * self.std.to(normed_tensor.device) + self.mean.to(normed_tensor.device)
    
    def state_dict(self):
        return {'mean': self.mean,
                'std': self.std}
    
    def load_state_dict(self, state_dict):
        self.mean = state_dict['mean']
        self.std = state_dict['std']
        self.device = self.mean.device  # Update device

class MLPDataset(Dataset):
    def __init__(self, X, y, normalizer):
        self.X = torch.from_numpy(X).float()
        self.y = torch.from_numpy(y).float()
        self.normalizer = normalizer
        
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.normalizer.norm(self.y[idx])
    
class CNNDataset(Dataset):
    def __init__(self, X, y, normalizer):
        # Reshape X to (samples, channels, length)
        X = X.reshape(-1, 1, 279)
        self.X = torch.from_numpy(X).float()
        self.y = torch.from_numpy(y).float()
        self.normalizer = normalizer
        
    def __len__(self):
        return len(self.X)
    
    def __getitem__(self, idx):
        return self.X[idx], self.normalizer.norm(self.y[idx])
    
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(50, 128),
            nn.SiLU(),
            nn.Linear(128, 256),
            nn.SiLU(),
            nn.Linear(256, 512),
            nn.SiLU(),
            nn.Linear(512, 1024),
            nn.SiLU(),
            nn.Linear(1024, 512),
            nn.SiLU(),
            nn.Linear(512, 256),
            nn.SiLU(),
            nn.Linear(256, 128),
            nn.SiLU(),
            nn.Linear(128, 64),
            nn.SiLU(),
            nn.Linear(64, 32),
            nn.SiLU(),
            nn.Linear(32, 3)  # Output layer for regression
        )
        
    def forward(self, x):
        return self.layers(x)

class CNN(nn.Module):
    def __init__(self, channels, conv_kernel_size, pool_kernel_size, num_out):
        super(CNN, self).__init__()
        assert len(channels) - 1 == len(conv_kernel_size)
        assert len(channels) - 1 == len(pool_kernel_size)
        layers = []
        for i in range(len(channels) - 1):
            layers.append(nn.Conv1d(
                in_channels=channels[i],
                out_channels=channels[i+1],
                kernel_size=conv_kernel_size[i],
                # padding=conv_kernel_size[i] // 2
            ))
            layers.append(nn.BatchNorm1d(num_features=channels[i+1]))
            layers.append(nn.SiLU())
            layers.append(nn.MaxPool1d(kernel_size=pool_kernel_size[i]))  
            # layers.append(nn.Dropout(p=0.1))     
        self.conv_layers = nn.Sequential(*layers)
        self.flatten = nn.Flatten()
        # Calculate the size after convolution and pooling
        with torch.no_grad():
            sample_input = torch.zeros(1, 1, 279)
            conv_output = self.conv_layers(sample_input)
            conv_output_size = conv_output.numel()
            print(f"conv_output_size: {conv_output_size}")
        self.fc_layers = nn.Sequential(
            nn.Linear(conv_output_size, 512),
            nn.SiLU(),
            nn.Linear(512, 128),
            nn.SiLU(),
            nn.Linear(128, 64),
            nn.SiLU(),
            nn.Linear(64, 32),
            nn.SiLU(),
            # nn.Dropout(p=0.3),
            nn.Linear(32, num_out)  # Output layer for regression
        )
        
    def forward(self, x):
        x = self.conv_layers(x)
        x = self.flatten(x)
        x = self.fc_layers(x)
        return x    
    
def train_model(model, normalizer, criterion, optimizer, train_loader, val_loader, ckpt_dir, device, num_epochs=500):
    best_valid_loss = np.inf
    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        for features, targets in train_loader:
            features, targets = features.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(features)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * features.size(0)
        epoch_loss = running_loss / len(train_loader.dataset)
        
        # Validation phase
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for features, targets in val_loader:
                features, targets = features.to(device), targets.to(device)
                outputs = model(features)
                targets = normalizer.denorm(targets)
                outputs = normalizer.denorm(outputs)
                loss = criterion(outputs, targets)
                val_loss += loss.item() * features.size(0)
        val_loss /= len(val_loader.dataset)
        print(f"Epoch {epoch+1}/{num_epochs}, Training Loss: {epoch_loss:.4f}, Validation Loss: {val_loss:.4f}")
        
        states = {
            'model_state_dict': model.state_dict(),
            "best_valid_loss": best_valid_loss,
            'epoch': epoch,
        }
        
        if val_loss < best_valid_loss:
            best_valid_loss = val_loss
            torch.save(states, os.path.join(ckpt_dir, 'model_best.pth'))
        torch.save(states, os.path.join(ckpt_dir, 'model.pth'))
        
def evaluate_model(model, normalizer, criterion, test_loader, device):
    model.eval()
    test_loss = 0.0
    with torch.no_grad():
        for features, targets in test_loader:
            features, targets = features.to(device), targets.to(device)
            outputs = model(features)
            targets = normalizer.denorm(targets)
            outputs = normalizer.denorm(outputs)
            loss = criterion(outputs, targets)
            test_loss += loss.item() * features.size(0)
    test_loss /= len(test_loader.dataset)
    print(f"\nTest Loss: {test_loss:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="mlp", help="model type")
    parser.add_argument("--data", type=str, default="CSI_CSE598_dataset200e3.mat", help="data file")
    parser.add_argument("--target", type=str, default="CSI_CSE598_dataset200e3.mat", help="target data file")
    parser.add_argument("--input", type=str, default="I4D_Nonoise", help="input")
    parser.add_argument("--channels", type=str, default="1,32,64", help="Comma-separated list of channels.")
    parser.add_argument("--conv_kernel_size", type=str, default="3,3", help="Comma-separated list of kernel size for conv.")
    parser.add_argument("--pool_kernel_size", type=str, default="2,2", help="Comma-separated list of kernel size for pool.")
    parser.add_argument("--epochs", type=int, default=500, help="Number of train epochs.")
    parser.add_argument("--bs", type=int, default=64, help="Batch size.")
    parser.add_argument("--num_out", type=int, default=3, help="Number of outputs.")
    parser.add_argument("--lr", type=float, default=1e-3, help="learning rate")
    parser.add_argument("--save_path", type=str, default="mlp_500_1e-3_64", help="save_path")

    try:
        args = parser.parse_args()
    except:
        # args = parser.parse_args([])
        args, unknown = parser.parse_known_args()
        
    args.channels = [int(x) for x in args.channels.split(',')]
    args.conv_kernel_size = [int(x) for x in args.conv_kernel_size.split(',')]
    args.pool_kernel_size = [int(x) for x in args.pool_kernel_size.split(',')]
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    print("Start loading data")
    
    with h5py.File(args.data, 'r') as f:
        X = np.transpose(np.array(f[args.input][:]))
        ground_truth_keys = [key for key in f.keys() if re.match(r'GroundTruthL\d+', key)]
        ground_truth_keys.sort(key=lambda x: int(x.replace('GroundTruthL', '')))
        ground_truth_data = [np.array(f[key][:]) for key in ground_truth_keys]
        y = np.concatenate(ground_truth_data, axis=1)
    print(f"shape of X: {X.shape}")
    print(f"shape of y: {y.shape}")
        
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.2, random_state=0)

    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.5, random_state=0)
    
    normalizer = Normalizer(torch.from_numpy(y_train).float())
    
    print("Train set shape:", X_train.shape, y_train.shape)
    print("Validation set shape:", X_val.shape, y_val.shape)
    print("Test set shape:", X_test.shape, y_test.shape)
    
    if args.model == 'mlp':
        model = MLP()
        train_dataset = MLPDataset(X_train, y_train)
        val_dataset = MLPDataset(X_val, y_val)
        test_dataset = MLPDataset(X_test, y_test)
    elif args.model == 'cnn':
        model = CNN(args.channels, args.conv_kernel_size, args.pool_kernel_size, num_out=args.num_out)
        train_dataset = CNNDataset(X_train, y_train, normalizer)
        val_dataset = CNNDataset(X_val, y_val, normalizer)
        test_dataset = CNNDataset(X_test, y_test, normalizer)
    else:
        raise TypeError("Wrong model type")

    train_loader = DataLoader(train_dataset, batch_size=args.bs, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=args.bs, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=args.bs, shuffle=False)
    
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    ckpt_dir = os.path.join('runs', args.save_path)
    if not os.path.exists(ckpt_dir):
        os.makedirs(ckpt_dir)
    
    model.to(device)
    train_model(model, normalizer, criterion, optimizer, train_loader, val_loader, ckpt_dir, device, args.epochs)
    ckpt_best = torch.load(os.path.join(ckpt_dir, 'model_best.pth'))
    model.load_state_dict(ckpt_best["model_state_dict"])
    evaluate_model(model, normalizer, criterion, test_loader, device)