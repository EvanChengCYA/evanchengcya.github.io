#### Description:
This package implements a machine-learning pipeline for classifying thin-film layer structures and predicting the thickness of each layer based on the input datasets. It uses a two-step process where the first step classifies the datasets into one of eight categories, and the second step predicts the thickness of the layers using the trained model.

#### Files Overview:
environment.yml: This file contains the dependencies required to set up the environment for running the code.
train.py: This script is responsible for training the model to predict the thickness of each layer based on the input classification results.
classification.py: This script takes the eight datasets as input, classifies them into one of the eight categories, and then feeds the results into the train.py script for further training.


#### Installation:
To set up the environment, follow these steps:

1.Create a conda environment using the environment.yml file:

conda env create -f environment.yml


2.Activate the environment:

conda activate environment.yml

#### Usage:

Run the classification script:
The classification.py script is used to classify the datasets into one of eight categories. After classification the results are fed into train.py to train and predict the thickness of each layer. 



#### Data Visualization

We include here a very short (only 5 sets of data points) for visualization of data.

 



